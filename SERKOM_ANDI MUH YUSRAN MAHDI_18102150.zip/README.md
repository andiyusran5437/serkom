
# Website pemesanan tiket wisata MKS

aplikasi pesan tiket dengan konsep crud, dan tampilan menggunakan bootstrap

## Authors

- [@andiyusran5437](https://github.com/andiyusran5437)


## Features

- Membuat pendaftaran tiket
- Menghitung Total harga tiket
- Menghapus pendaftaran
- mengedit pendaftaran


## Installation

- PHP native
- VS Code
- Xampp for apache, php, mysql
- Access Internet
## Documentation

[getbootstrap](https://getbootstrap.com/)


## 🚀 About Me
I'm a calon front end...


## 🛠 Skills
Javascript(Low),PHP, HTML, CSS...

